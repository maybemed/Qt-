#ifndef SET_NEW_H
#define SET_NEW_H

#include <QDialog>

namespace Ui {
class set_new;
}

class set_new : public QDialog
{
    Q_OBJECT

public:
    explicit set_new(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    ~set_new();

signals:
    void set_newBack();
    void bgm_set();
    void difficult_set();
    void endless_set();

private:
    Ui::set_new *ui;
};

#endif // SET_NEW_H
