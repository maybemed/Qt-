#include "set_new.h"
#include "ui_set_new.h"
#include"mypushbutton.h"
#include<QPainter>
#include<QTimer>
set_new::set_new(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::set_new)
{
this->setFixedSize(1000,540);
this->setWindowTitle("设置");
this->setWindowModality(Qt::ApplicationModal);
this->setWindowOpacity(1); //窗口整体透明度，0-1 从全透明到不透明
this->setWindowFlags(Qt::FramelessWindowHint); //设置无边框风格
this->setAttribute(Qt::WA_TranslucentBackground); //设置背景透明，允许鼠标穿透
//返回按钮
MyPushButton *backbtn=new MyPushButton(":/image/back_set.PNG",1.0,1.0);
backbtn->setParent(this);
backbtn->move(this->width()*0.5-53,358);

connect(backbtn,&MyPushButton::clicked,[=]{
    backbtn->zoom1();
    backbtn->zoom2();
    //延时
    QTimer::singleShot(100,this,[=](){
        emit this->set_newBack();
    });
});
//背景音乐按钮
MyPushButton *bgmbtn=new MyPushButton(":/image/bgm.PNG",1.0,1.0);
bgmbtn->setParent(this);
bgmbtn->move(this->width()*0.5-53,220);

connect(bgmbtn,&MyPushButton::clicked,[=]{
    bgmbtn->zoom1();
    bgmbtn->zoom2();
    //延时
    QTimer::singleShot(100,this,[=](){
        emit this->bgm_set();
    });
});
//难度按钮
MyPushButton *difficultbtn=new MyPushButton(":/image/difficult.PNG",1.0,1.0);
difficultbtn->setParent(this);
difficultbtn->move(this->width()*0.5-53,266);

connect(difficultbtn,&MyPushButton::clicked,[=]{
    difficultbtn->zoom1();
    difficultbtn->zoom2();
    //延时
    QTimer::singleShot(100,this,[=](){
        emit this->difficult_set();
    });
});
//无敌按钮
MyPushButton *endlessbtn=new MyPushButton(":/image/endless.PNG",1.0,1.0);
endlessbtn->setParent(this);
endlessbtn->move(this->width()*0.5-53,312);

connect(endlessbtn,&MyPushButton::clicked,[=]{
    endlessbtn->zoom1();
    endlessbtn->zoom2();
    //延时
    QTimer::singleShot(100,this,[=](){
        emit this->endless_set();
    });
});
}
void set_new::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/block.PNG");
    painter.drawPixmap(200,100,600,381,pix);
}

set_new::~set_new()
{
    delete ui;
}
