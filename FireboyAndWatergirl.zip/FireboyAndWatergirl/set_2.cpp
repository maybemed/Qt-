#include "set_2.h"
#include"mypushbutton.h"
#include<QPainter>
#include<QTimer>
set_2::set_2(QWidget *parent)
    : QMainWindow(parent)
{
    this->setFixedSize(1000,540);
    this->setWindowTitle("难度选择");
    this->setWindowModality(Qt::ApplicationModal);
    this->setWindowOpacity(1); //窗口整体透明度，0-1 从全透明到不透明
    this->setWindowFlags(Qt::FramelessWindowHint); //设置无边框风格
    this->setAttribute(Qt::WA_TranslucentBackground); //设置背景透明，允许鼠标穿透
    //返回按钮
    MyPushButton *back2btn=new MyPushButton(":/image/last.PNG",1.0,1.0);
    back2btn->setParent(this);
    back2btn->move(this->width()*0.5-53,358);

    connect(back2btn,&MyPushButton::clicked,[=]{
        back2btn->zoom1();
        back2btn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->set_2Back();
        });
    });
    //简单按钮
    MyPushButton *easybtn=new MyPushButton(":/image/easy.PNG",1.0,1.0);
    easybtn->setParent(this);
    easybtn->move(this->width()*0.5-53,220);

    connect(easybtn,&MyPushButton::clicked,[=]{
        easybtn->zoom1();
        easybtn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->easy_choose();
        });
    });
    //普通按钮
    MyPushButton *normalbtn=new MyPushButton(":/image/normal.PNG",1.0,1.0);
    normalbtn->setParent(this);
    normalbtn->move(this->width()*0.5-53,266);

    connect(normalbtn,&MyPushButton::clicked,[=]{
        normalbtn->zoom1();
        normalbtn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->normal_choose();
        });
    });
    //困难按钮
    MyPushButton *diffbtn=new MyPushButton(":/image/diff.PNG",1.0,1.0);
    diffbtn->setParent(this);
    diffbtn->move(this->width()*0.5-53,312);

    connect(diffbtn,&MyPushButton::clicked,[=]{
        diffbtn->zoom1();
        diffbtn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->diff_choose();
        });
    });
}
void set_2::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/block.PNG");
    painter.drawPixmap(200,100,600,381,pix);
}
