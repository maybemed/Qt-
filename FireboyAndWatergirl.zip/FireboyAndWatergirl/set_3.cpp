#include "set_3.h"
#include"mypushbutton.h"
#include<QPainter>
#include<QTimer>
set_3::set_3(QWidget *parent)
    : QMainWindow(parent)
{
    this->setFixedSize(1000,540);
    this->setWindowTitle("无敌模式");
    this->setWindowModality(Qt::ApplicationModal);
    this->setWindowOpacity(1); //窗口整体透明度，0-1 从全透明到不透明
    this->setWindowFlags(Qt::FramelessWindowHint); //设置无边框风格
    this->setAttribute(Qt::WA_TranslucentBackground); //设置背景透明，允许鼠标穿透
    //返回按钮
    MyPushButton *back3btn=new MyPushButton(":/image/last_final.PNG",1.0,1.0);
    back3btn->setParent(this);
    back3btn->move(this->width()*0.5-75,325);

    connect(back3btn,&MyPushButton::clicked,[=]{
        back3btn->zoom1();
        back3btn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->set_3Back();
        });
    });
    //开按钮
    MyPushButton *openbtn=new MyPushButton(":/image/end_open.PNG",1.0,1.0);
    openbtn->setParent(this);
    openbtn->move(this->width()*0.5-155,220);

    connect(openbtn,&MyPushButton::clicked,[=]{
        openbtn->zoom1();
        openbtn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->endless_open();
        });
    });
    //关按钮
    MyPushButton *closebtn=new MyPushButton(":/image/end_close.PNG",1.0,1.0);
    closebtn->setParent(this);
    closebtn->move(this->width()*0.5+5,220);

    connect(closebtn,&MyPushButton::clicked,[=]{
        closebtn->zoom1();
        closebtn->zoom2();
        //延时
        QTimer::singleShot(100,this,[=](){
            emit this->endless_close();
        });
    });
}
void set_3::paintEvent(QPaintEvent*)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/image/block.PNG");
    painter.drawPixmap(200,100,600,381,pix);
}
