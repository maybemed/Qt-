#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include"more.h"
#include"winend.h"
#include"loseend.h"
#include"winend2.h"
#include"shadewindow.h"
#include"set_new.h"
#include"set.h"
#include"set_2.h"
#include"set_3.h"
#include"choose.h"
#include"firstgame.h"
#include"game.h"
#include"thirdgame.h"
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    //画背景图
    void paintEvent(QPaintEvent*);


    set_new*se=NULL;
    more*mo=NULL;
    loseend*lose=NULL;
    shadewindow*shade=NULL;

    set*set1=NULL;
    set_2*set2=NULL;
    set_3*set3=NULL;

    Choose*cho=NULL;

    firstgame*gam1=NULL;
    game*gam2=NULL;
    thirdgame*gam3=NULL;

    winend*win1_1=NULL;
    winend2*win1_2=NULL;
    winend*win2_1=NULL;
    winend2*win2_2=NULL;
    winend*win3_1=NULL;
    winend2*win3_2=NULL;
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
