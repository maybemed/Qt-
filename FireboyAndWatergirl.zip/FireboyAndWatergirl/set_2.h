#ifndef SET_2_H
#define SET_2_H

#include <QMainWindow>

class set_2 : public QMainWindow
{
    Q_OBJECT
public:
    explicit set_2(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);

signals:
    void set_2Back();
    void easy_choose();
    void normal_choose();
    void diff_choose();
};
#endif // SET_2_H
