#ifndef CHOOSE_H
#define CHOOSE_H

#include <QDialog>

namespace Ui {
class Choose;
}

class Choose : public QDialog
{
    Q_OBJECT

public:
    explicit Choose(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    ~Choose();

signals:
    void chooseBack();
    void choose_1();
    void choose_2();
    void choose_3();

private:
    Ui::Choose *ui;
};

#endif // CHOOSE_H
